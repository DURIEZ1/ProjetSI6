<?php
session_start();
if(!isset($_SESSION['membre'])) {
    header('location: connexion.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>La Formule 1</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../composant/css/main.css" />
    <link rel="stylesheet" href="../composant/bootstrap/css/bootstrap.min.css" />

    <script src="../composant/jquery.js"></script>
    <script src="../composant/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../composant/confirm/jquery-confirm.min.js"></script>
    <script src="../composant/personnel/class.std.js"></script>
    <script src="js/index.js"></script>
</head>
<body>
    <div id="menu"></div>
    <div class="corp_acces">
        <div class="fond">
            <h3>Présentation rapide de la formule 1</h3>
            <p>La Formule 1, communément abrégée en F1, est une discipline de sport automobile considérée comme la catégorie reine de ce sport. Elle a pris au fil des ans une dimension mondiale et elle est, avec les Jeux olympiques et la Coupe du monde de football, l'un des événements sportifs les plus médiatisés.
                Chaque année depuis 1950, un championnat mondial des pilotes est organisé, complété depuis 1958 par un championnat mondial des constructeurs automobiles. La compétition est basée sur des Grands Prix, courses à bord de voitures monoplaces disputées sur circuits routiers fermés permanents mais parfois tracés en ville et temporaires, comme à Monaco, Singapour, et Bakou.
                Cette discipline sportive, régie par la Fédération internationale de l'automobile (FIA), est gérée par la Formula One Administration (FOA) et un ensemble de sociétés satellites contrôlées par Liberty Media. Après l'ère des artisans des années 1960 et 1970, elle a peu à peu attiré les grands constructeurs automobiles mondiaux qui y investissent des sommes élevées, en espérant tirer profit des retombées médiatiques d'éventuels succès. La Formule 1 est considérée comme la vitrine technologique de l'industrie automobile qui y expérimente des nouveautés techniques, parfois issues de la technologie spatiale et susceptibles d'être adaptées ensuite sur les voitures de série.</p>
        </div>
    </div>
</body>
</html>
