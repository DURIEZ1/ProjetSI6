"use strict";

$(function () {
    $('#menu').load('ajax/menu.html');
})