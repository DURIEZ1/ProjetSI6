"use strict";

$(function () {
    $.getJSON("ajax/getDonnees.php", afficher);
    $('#menu').load("../ajax/menu.html");
});


function afficher(data) {
    for (const pilote of data) {
        let carte = $('<div>', {class: "card mb-3"});
        let entete = $('<div>', {class: "card-header bg-dark text-white text-center"});
        entete.html('<b>'+ pilote.nom + " " + pilote.prenom +'</b>');
        carte.append(entete);

        let corps = $('<div>', {class: "card-body text-center"});
        let img = $('<img>', {src: "../../composant/image/pilote/" + pilote.id + ".jpg", alt: "Pas de photos", class:"w-100"});
        corps.append(img);
        carte.append(corps);

        let footer = $('<div>', {class: "card-footer text-muted text-center"});
        footer.html('<b>'+ 'Date de naissance : ' + pilote.dateNaissance + '<br/>' + 'Nationalité : ' + pilote.nationalite + '<br/>' + 'Sexe : ' + pilote.sexe + '</b>');
        carte.append(footer);

        $("#lesCartes").append(carte);
    }
}
