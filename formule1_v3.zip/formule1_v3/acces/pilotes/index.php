<?php
session_start();
if(!isset($_SESSION['membre'])) {
    header('location: connexion.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Formule 1</title>
    <!-- Mise en place des liens pour le style -->
    <link rel="stylesheet" href="../../composant/css/main.css" />
    <link rel="stylesheet" href="../../composant/bootstrap/css/bootstrap.min.css" />

    <!-- Mise en place de script (js, jquery, etc..) -->
    <script src="../../composant/jquery.js"></script>
    <script src="../../composant/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Mise en place de script perso -->
    <script src="js/pilote.js"></script>
</head>
<body>
    <div id="menu"></div>
    <div class="corp_pilotes align-items-center">
            <div class="card bg-transparent border-0 col-md-10" style="margin-top: 200px;">
                <div id='lesCartes' class="card-columns "></div>
            </div>
    </div>
</body>
</html>
