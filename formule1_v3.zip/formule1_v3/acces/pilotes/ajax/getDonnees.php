<?php
require '../../../class/class.database.inc.php';
$db = Database::getInstance();

$sql = <<<EOD
    select id, nom, prenom, nationalite, date_format(dateNaissance, '%d/%m/%Y') as dateNaissance, sexe, points, victoires, podiums
    FROM pilote2019
    order by nom, prenom
EOD;
$curseur = $db->query($sql);
$lesLignes = $curseur->fetchAll(PDO::FETCH_ASSOC);
$curseur->closeCursor();
echo json_encode($lesLignes);
