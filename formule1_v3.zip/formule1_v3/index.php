<?php
date_default_timezone_set("Europe/Paris");
session_start();

if (!isset($_SESSION['membre'])) {
    header('location: connexion.php');
    exit;
} else {
    header('location: acces/index.php');
    exit;
}