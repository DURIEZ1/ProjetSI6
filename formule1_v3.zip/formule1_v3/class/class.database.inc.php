<?php

class Database
{
    private static $_instance; // Permet de stocker l'adresse

    public static function getInstance()
    {
        if (is_null(self::$_instance)) {
            $dbHost = 'localhost';
            $dbUser = 'root';
            $dbPassword = 'root';
            $dbBase = 'formule1';
            $dbPort = '3306';
            try {
                $chaine = "mysql:host=$dbHost;dbname=$dbBase;port=$dbPort";
                $db = new PDO ($chaine, $dbUser, $dbPassword);
                $db->exec("SET NAMES 'utf8'");
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$_instance = $db;
            } catch (PDOException $e) {
                ?>
                <h3 style='background-color: #fcfcfc; color: red; font-weight: bold; border: 5px solid #cfcfcf;'>
                    Impossible de se connecter à la base de données, merci de vérifier les paramètres ou contacter un administrateur
                </h3>
                <?php
                exit();
            }
        }
        return self::$_instance;
    }
}