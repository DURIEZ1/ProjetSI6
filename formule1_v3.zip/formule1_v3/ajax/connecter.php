<?php
session_start(); /*Lancement de la session */
require '../class/class.database.inc.php'; /*Appel de la connexion pour la base */

$login = $_POST["login"]; /*Appel de la méthode lancer sur le formaulaire de connexion pour récupéré le login*/
$mdp = $_POST["mdp"]; /*Appel de la méthode lancer sur le formulaire de connexion pour récupéré le mdp*/

$db = Database::getInstance(); /*Appel de la base*/
$sql = <<<EOD
    select prenom, mdp 
    from connexion 
    where login = :login;
EOD;
/*On récupére les informations demandés par le formulaire dans la base*/

$curseur = $db->prepare($sql);
$curseur->bindParam('login', $login);
$curseur->execute();
$laLigne = $curseur->fetch(PDO::FETCH_ASSOC);
$curseur->closeCursor();
if (!$laLigne) {
    echo 0;
} else if ($laLigne['mdp'] != $mdp) {
    echo 0;
} else {
    $_SESSION['membre']['login'] = $login;
    $_SESSION['membre']['prenom'] = $laLigne['prenom'];
    echo 1;
}
/* On vérifie grâce à la db si les informations demandé sont les mêmes que dans le formulaire */
/* Pour la première ligne */
/* La deuxième ligne on vérifie que le mot de passe correspond si un 0 est renvoyé alors non */
/* La troisième ligne on vérifie que les ékéments corresponde, login, prenom, mdp etc, et si oui alors on valide la connexion de l'utilisateur */
