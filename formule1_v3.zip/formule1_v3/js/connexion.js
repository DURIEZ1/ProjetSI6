"use strict";

let mdp;
let login;

$(function () {
    $('#login').focus();

    $('#login').keypress(function (e) {
        if(e.key === 13) {
            let mdp = document.getElementById('mdp');
            if (mdp.value.length === 0) {
                mdp.focus();
            }else {
                connexion();
            }
            return false;
        }
    });

    $('#mdp').keypress(function (e) {
        if (e.key === 13) {
            let login = document.getElementById('login');
            if (login.value.length === 0) {
                login.focus();
            } else {
                if (this.value.length > 0) {
                    connexion();
                }
            }
            return false;
        }
    });

    $('#btnConnexion').click(connexion);
});


function connexion() {
    let login = document.getElementById('login');
    let mdp = document.getElementById('mdp');

    $.ajax({
        url: 'ajax/connecter.php',
        type: 'POST',
        data: {login: login.value, mdp: mdp.value},
        dataType: "json",
        error: function (request, error) {
            $.dialog({title: '', content: request.responseText, type: 'red', typeAnimated: true});
        },
        success: function (data) {
            if (data === 1) {
                location.href = "acces/index.php";
            } else {
                Std.afficherMessage("msg", "Attention les informations renseigner sont incorrects", "alert-danger", 0);
                login.focus();
                mdp.value = '';
            }
        }
    })
}