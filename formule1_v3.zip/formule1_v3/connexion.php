<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Formule 1 | Espace connexion</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="composant/css/main.css" />
        <link rel="stylesheet" href="composant/bootstrap/css/bootstrap.min.css" />

        <script src="composant/jquery.js"></script>
        <script src="composant/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="composant/confirm/jquery-confirm.min.js"></script>
        <script src="composant/personnel/class.std.js"></script>
        <script src="js/connexion.js"></script>
    </head>

    <body>
        <div class="liseret">
            <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top align-content-center">
                <a class="navbar-brand" href="index.php"><img src="composant/image/logo_formule1.jpg" height="100px" width="100px"/></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content"
                        aria-controls="nav-content" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </nav>
        </div>
    <div class="corp_connexion align-items-center">
        <div class="card w-50 index">
            <div class="card-header bg-dark">
                <h3>Accès à l'espace de connexion</h3>
            </div>
            <div class="card-body">
                <div id="msg"></div>
                    <div class="form-group">
                        <label for="login">Votre login :</label>
                        <input type="text" id="login" class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label for="mdp">Votre mot de passe :</label>
                        <input type="password" class="form-control" id="mdp" />
                    </div>
            </div>
            <div class="card-footer">
                <button class="btn btn-success float-right" id='btnConnexion' >Connexion</button>
            </div>
        </div>
    </div>
    </body>
</html>
